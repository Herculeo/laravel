<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/home', function () {
    return view('welcome');
});
Auth::routes();


Route::get('/albums', 'AlbumsController@index')->name('index');
Route::get('/albums/create', 'AlbumsController@create')->name('create');
Route::get('/albums/{albums}', 'AlbumsController@show')->name('show');
Route::get('/albums/{albums}/edit', 'AlbumsController@edit')->name('edit');
Route::post('/albums', 'AlbumsController@store')->name('store');
Route::post('/pictures', 'PicturesController@store')->name('store');
Route::get('/', 'HomeController@index')->name('home');