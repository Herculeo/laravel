@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <h1>Albums</h1>
                        @if (Route::has('login'))
                                @auth
                                <a href="albums/create">nieuw +</a>
                                @else
                                @endauth

                        @endif
                </div>

                    @foreach ($albums as $album)
                            <div class="card" style="width: 18rem;">
                                <a href="/albums/{{ $album->id }}">
                                    <img src="{{ asset('images/' . $album->cover) }}" height="300px">
                                </a>
                                <a href="/albums/{{ $album->id }}">
                                    <h5 class="card-title text-center">{{$album->title}}</h5>
                                </a>
                                {{--<form action="{{ route('albums.delete', $album->id) }}" method="POST"--}}
                                      {{--style="display: inline"--}}
                                      {{--onsubmit="return confirm('Are you sure?');">--}}
                                    {{--<input type="hidden" name="_method" value="DELETE">--}}
                                    {{--{{ csrf_field() }}--}}
                                    {{--<button class="btn btn-danger">Delete</button>--}}
                                {{--</form>--}}
                            </div>

                    @endforeach
            </div>
        </div>
    </div>
@endsection