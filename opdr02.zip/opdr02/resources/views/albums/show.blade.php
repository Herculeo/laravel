@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <h1>{{$album->title}}</h1>


                    <form action="/pictures" method="post" enctype="multipart/form-data">
                        {{csrf_field()}}
                        <input type="hidden" name="album_id" value={{$album->id}}/>
                        <input type="file" name="cover" class="form-control">
                        <input type="submit" value="Submit" class="form-control">
                    </form>

                    <?php
                        use App\Picture;
                        $pictures = Picture::all();
                    ?>
                    @foreach ($pictures as $picture)
                        <div class="card" style="width: 18rem;">
                            <img src="{{ asset('images/' . $picture->picture) }}" height="300px">
                            {{--<form action="{{ route('albums.delete', $album->id) }}" method="POST"--}}
                            {{--style="display: inline"--}}
                            {{--onsubmit="return confirm('Are you sure?');">--}}
                            {{--<input type="hidden" name="_method" value="DELETE">--}}
                            {{--{{ csrf_field() }}--}}
                            {{--<button class="btn btn-danger">Delete</button>--}}
                            {{--</form>--}}
                        </div>

                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection