<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <h1><?php echo e($album->title); ?></h1>


                    <form action="/pictures" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="album_id" value=<?php echo e($album->id); ?>/>
                        <input type="file" name="cover" class="form-control">
                        <input type="submit" value="Submit" class="form-control">
                    </form>

                    <?php
                        use App\Picture;
                        $pictures = Picture::all();
                    ?>
                    <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card" style="width: 18rem;">
                            <img src="<?php echo e(asset('images/' . $picture->picture)); ?>" height="300px">
                            
                            
                            
                            
                            
                            
                            
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>