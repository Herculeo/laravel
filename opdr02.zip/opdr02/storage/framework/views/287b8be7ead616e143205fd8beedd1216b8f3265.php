<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <h1>Albums</h1>

                    <form action="/albums" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="text" name="title" value="<?php echo e(old('title')); ?>"/>
                        <input type="file" name="picture" class="form-control">
                        <input type="submit" value="Submit" class="form-control">
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>