<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <h1>Albums
                        <?php if(Route::has('login')): ?>
                                <?php if(auth()->guard()->check()): ?>
                                <a href="albums/create">nieuw +</a>
                                <?php else: ?>
                                <?php endif; ?>

                        <?php endif; ?>
            </div>
                    </h1>
                    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card" style="width: 18rem;">
                                <a href="/albums/<?php echo e($album->id); ?>">
                                    <img src="<?php echo e(asset('images/' . $album->cover)); ?>" height="300px">
                                </a>
                                <a href="/albums/<?php echo e($album->id); ?>">
                                    <h5 class="card-title text-center"><?php echo e($album->title); ?></h5>
                                </a>
                                
                                      
                                      
                                    
                                    
                                    
                                
                            </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>