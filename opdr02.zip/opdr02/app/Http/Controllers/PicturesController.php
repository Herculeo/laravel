<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Picture;

class PicturesController extends Controller
{
    public function store(Request $request)
    {
        if ($file = $request->file('picture')) {
            $name = $file->getClientOriginalName();
            if ($file->move('images', $name)) {
                $picture = new Picture();
                $picture->picture = $name;
                $picture->album_id = $request->album_id;
                $picture->save();
                return view('albums.index');
            }
        }
        return view('albums.index');
    }
}
