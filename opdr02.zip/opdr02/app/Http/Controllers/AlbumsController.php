<?php

namespace App\Http\Controllers;

use App\Album;
use Illuminate\Http\Request;

class AlbumsController extends Controller
{
    public function index()
    {
        $albums = Album::all();
        return view('albums.index', compact('albums'));
    }

    public function create()
    {
        return view('albums.create');
    }

    public function store(Request $request)
    {
        if ($file = $request->file('cover')) {
            $name = $file->getClientOriginalName();
            if ($file->move('images', $name)) {
                $album = new Album();
                $album->cover = $name;
                $album->title = $request->title;
                $album->save();
                return redirect()->route('/albums.index')->with(['message' => 'Album added successfully']);
            }
        }
        return view('/albums.index');
    }

    public function edit($id)
    {
        $album = Album::findOrFail($id);
        return view('albums.edit', compact('album'));
    }

    public function show($id)
    {
        $album = Album::findOrFail($id);
        return view('albums.show', compact('album'));
    }
}
