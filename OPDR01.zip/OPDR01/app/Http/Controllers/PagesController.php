<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Album;
use App\Photo;

class PagesController extends Controller
{
    public function index()
    {
        $albums = Album::all();
        return view('useralbums.index', compact('albums'));
    }

    public function photos()
    {
        $photos = Album::find(21)->Photo;
        return view('useralbums/photos', compact('photos'));
    }
}
