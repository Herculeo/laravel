<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <?php if(session('message')): ?>
                        <div class="alert alert-info"><?php echo e(session('message')); ?></div>
                    <?php endif; ?>
                    <div class="panel-heading">Albums
                        <?php if(Route::has('login')): ?>
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('albums.create')); ?>" class="btn btn-default">Add New Album +</a>
                            <?php else: ?>
                            <?php endif; ?>
                        <?php endif; ?>

                    </div>

                    <div class="panel-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>

                                <th>Cover</th>
                                <th>Name</th>
                                    <th>Actions</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                        <td>
                                            <a href="<?php echo e(route('photos.index')); ?>"><img src="<?php echo e(asset('images/' . $album->cover_image)); ?>" width="60px" height="60px"></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('photos.index')); ?>"><?php echo e($album->name); ?></a>
                                        </td>

                                    <?php if(Route::has('login')): ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <td>
                                                <a href="<?php echo e(route('albums.edit', $album->id)); ?>" class="btn btn-default">Edit</a>
                                                <form action="<?php echo e(route('albums.destroy', $album->id)); ?>" method="POST"
                                                      style="display: inline"
                                                      onsubmit="return confirm('Are you sure?');">
                                                    <input type="hidden" name="_method" value="DELETE">
                                                    <?php echo e(csrf_field()); ?>

                                                    <button class="btn btn-danger">Delete</button>
                                                </form>
                                            </td>
                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">No entries found.</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function getIDs()
        {
            var ids = [];
            $('.checkbox_delete').each(function () {
                if($(this).is(":checked")) {
                    ids.push($(this).val());
                }
            });
            $('#ids').val(ids.join());
        }

        $(".checkbox_all").click(function(){
            $('input.checkbox_delete').prop('checked', this.checked);
            getIDs();
        });

        $('.checkbox_delete').change(function() {
            getIDs();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>