<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <?php if(Route::has('login')): ?>
                        <?php if(auth()->guard()->check()): ?>
                    <div class="panel-heading">Add New Album</div>

                    <div class="panel-body">
                        <?php if($errors->count() > 0): ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>


                                    <form action="<?php echo e(route('albums.store')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        Cover name:
                                        <br />
                                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" />
                                        <br /><br />
                                        Cover image:
                                        <br />
                                        <input type="text" name="cover_image" value="<?php echo e(old('cover_image')); ?>" />
                                        <input type="file" name="cover_image" class="form-control" value="<?php echo e(old('cover_image')); ?>"/>
                                        <br /><br />
                                        <input type="submit" value="Submit" class="btn btn-default" />
                                    </form>
                                <?php else: ?>
                                    geen toegang
                                <?php endif; ?>
                            <?php endif; ?>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>