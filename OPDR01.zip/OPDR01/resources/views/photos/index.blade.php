@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    @if (session('message'))
                        <div class="alert alert-info">{{ session('message') }}</div>
                    @endif
                    <div class="panel-heading">
                        <?php
                            use App\Album;

                            $albums = Album::All();
                            ?>

                            @forelse($albums as $album)
                                {{ $album->name }}
                            @empty
                                No entries found.

                            @endforelse


                                <a href="{{ route('photos.create') }}" class="btn btn-default">Add New Photo +</a>
                    </div>

                    <div class="panel-body">
                        <table class="table table-bordered">
                            <thead>
                            <tr>
                                <th>
                                    <input type="checkbox" class="checkbox_all">
                                </th>
                                <th>Photo</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse($photos as $photo)
                                <tr>
                                    <td>
                                        <input type="checkbox" class="checkbox_delete" name="entries_to_delete[]" value="{{ $photo->id }}" />
                                    </td>
                                    <td><img src="{{ asset('images/' . $photo->photo) }}" width="100px" height="100px"></td>
                                    <td>
                                        <form action="{{ route('photos.destroy', $photo->id) }}" method="POST" style="display: inline" onsubmit="return confirm('Are you sure?');">
                                            <input type="hidden" name="_method" value="DELETE">
                                            {{ csrf_field() }}
                                            <button class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>

                                </tr>
                            @empty
                                <tr>
                                    <td colspan="3">No entries found.</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>


@endsection